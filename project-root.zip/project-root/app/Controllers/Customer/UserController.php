<?php

namespace App\Controllers\Customer;

use CodeIgniter\Controller;
use App\Models\CustomerModel;
use App\Models\PesananModel;

class UserController extends Controller
{
    public function index()
    {
        // Initialize models
        $customerModel = new CustomerModel();
        $pesananModel = new PesananModel();

        // Get user_id from session
        $userId = session()->get('user_id');

        // Get customer data
        $data['customer'] = $customerModel->where('user_id', $userId)->first();

        // If customer data exists, get their orders
        if ($data['customer']) {
            $data['pesanan'] = $pesananModel->getPesananByCustomersId($data['customer']['id']);
        } else {
            $data['pesanan'] = [];
        }

        // Tampilkan dashboard customer dengan data
        return view('customer/dashboard', $data);
    }
}
