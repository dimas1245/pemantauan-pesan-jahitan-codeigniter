<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use App\Models\PesananModel;
use App\Models\UserModel;

class ReportController extends BaseController
{
    protected $customerModel;
    protected $pesananModel;
    protected $userModel;

    public function __construct()
    {
        $this->customerModel = new CustomerModel();
        $this->pesananModel = new PesananModel();
        $this->userModel = new UserModel();
    }

    public function viewRegistrationReport()
    {
        $data['users'] = $this->userModel->select('users.*, customers.nama_customer')
            ->join('customers', 'customers.user_id = users.id', 'left')
            ->findAll();

        return view('reports/view_registration_report', $data);
    }

    public function getFilteredUsers()
    {
        $role = $this->request->getPost('role');

        $query = $this->userModel->select('users.*, customers.nama_customer')
            ->join('customers', 'customers.user_id = users.id', 'left');

        if ($role !== '') {
            $query->where('users.role_id', $role);
        }

        $users = $query->findAll();

        $html = '';
        foreach ($users as $key => $user) {
            $html .= '<tr>';
            $html .= '<td>' . ($key + 1) . '</td>';
            $html .= '<td>' . $user['username'] . '</td>';
            $html .= '<td class="password-cell">' . $user['password'] . '</td>';
            $html .= '<td>' . ($user['role_id'] == 1 ? 'Admin' : 'Customer') . '</td>';
            $html .= '<td>' . (!empty($user['nama_customer']) ? 'Terdaftar' : 'Belum Terdaftar') . '</td>';
            $html .= '<td><button onclick="resetPassword(' . $user['id'] . ')" class="btn btn-warning btn-sm">Reset Password</button></td>';
            $html .= '</tr>';
        }

        return $html;
    }

    public function printRegistration()
    {
        $role = $this->request->getGet('role');

        $query = $this->userModel->select('users.*, customers.nama_customer')
            ->join('customers', 'customers.user_id = users.id', 'left');

        if ($role !== '') {
            $query->where('users.role_id', $role);
        }

        $data['users'] = $query->findAll();

        // Load view
        $html = view('reports/registration_report', $data);

        // Setup PDF
        $options = new \Dompdf\Options();
        $options->setDefaultFont('Courier');
        $dompdf = new \Dompdf\Dompdf($options);

        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        return $dompdf->stream('laporan_user.pdf', ['Attachment' => false]);
    }

    public function customerReport()
    {
        // Get all customers for dropdown
        $data['customers'] = $this->customerModel->findAll();

        // Get initial data (all orders grouped by customer)
        $data['orders'] = $this->pesananModel->select('customers.nama_customer, customers.alamat, customers.no_telepon, COUNT(pesanan.id) as total_orders, SUM(pesanan.jumlah_pesan * pesanan.harga) as total_amount')
            ->join('customers', 'customers.id = pesanan.user_id')
            ->groupBy('customers.id, customers.nama_customer, customers.alamat, customers.no_telepon')
            ->findAll();

        return view('reports/view_customer_report', $data);
    }

    public function getFilteredCustomerReport()
    {
        $startDate = $this->request->getPost('start_date');
        $endDate = $this->request->getPost('end_date');
        $customerId = $this->request->getPost('customer_id');

        $query = $this->pesananModel->select('customers.nama_customer, customers.alamat, customers.no_telepon, COUNT(pesanan.id) as total_orders, SUM(pesanan.jumlah_pesan * pesanan.harga) as total_amount')
            ->join('customers', 'customers.id = pesanan.user_id');

        // Apply filters
        if ($startDate && $endDate) {
            $query->where('pesanan.tanggal_pesan >=', $startDate)
                ->where('pesanan.tanggal_pesan <=', $endDate . ' 23:59:59');
        }

        if ($customerId) {
            $query->where('customers.id', $customerId);
        }

        $orders = $query->groupBy('customers.id, customers.nama_customer, customers.alamat, customers.no_telepon')
            ->findAll();

        // Build HTML for response
        $html = '';
        foreach ($orders as $key => $order) {
            $html .= '<tr>';
            $html .= '<td>' . ($key + 1) . '</td>';
            $html .= '<td>' . $order['nama_customer'] . '</td>';
            $html .= '<td>' . $order['alamat'] . '</td>';
            $html .= '<td>' . $order['no_telepon'] . '</td>';
            $html .= '<td>' . $order['total_orders'] . '</td>';
            $html .= '<td>Rp ' . number_format($order['total_amount'], 0, ',', '.') . '</td>';
            $html .= '</tr>';
        }

        return $this->response->setJSON(['html' => $html]);
    }

    public function printCustomerReport()
    {
        $startDate = $this->request->getGet('start_date');
        $endDate = $this->request->getGet('end_date');
        $customerId = $this->request->getGet('customer_id');

        $query = $this->pesananModel->select('customers.nama_customer, customers.alamat, customers.no_telepon, COUNT(pesanan.id) as total_orders, SUM(pesanan.jumlah_pesan * pesanan.harga) as total_amount')
            ->join('customers', 'customers.id = pesanan.user_id');

        // Apply filters
        if ($startDate && $endDate) {
            $query->where('pesanan.tanggal_pesan >=', $startDate)
                ->where('pesanan.tanggal_pesan <=', $endDate . ' 23:59:59');
        }

        if ($customerId) {
            $query->where('customers.id', $customerId);
        }

        $data['orders'] = $query->groupBy('customers.id, customers.nama_customer, customers.alamat, customers.no_telepon')
            ->findAll();
        $data['start_date'] = $startDate;
        $data['end_date'] = $endDate;

        // Load view for PDF
        $html = view('reports/customer_report_pdf', $data);

        // Setup PDF
        $options = new \Dompdf\Options();
        $options->setDefaultFont('Courier');
        $dompdf = new \Dompdf\Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        return $dompdf->stream('laporan_customer.pdf', ['Attachment' => false]);
    }

    public function orderReport()
    {
        // Get initial data (all orders sorted by oldest date first)
        $data['orders'] = $this->pesananModel->select('pesanan.*, customers.nama_customer, customers.alamat, customers.no_telepon')
            ->join('customers', 'customers.id = pesanan.user_id')
            ->orderBy('tanggal_pesan', 'ASC')
            ->findAll();

        return view('reports/view_order_report', $data);
    }

    public function getFilteredOrderReport()
    {
        $startDate = $this->request->getPost('start_date');
        $endDate = $this->request->getPost('end_date');
        $status = $this->request->getPost('status');

        $query = $this->pesananModel->select('pesanan.*, customers.nama_customer, customers.alamat, customers.no_telepon')
            ->join('customers', 'customers.id = pesanan.user_id');

        // Apply filters
        if ($startDate && $endDate) {
            $query->where('pesanan.tanggal_pesan >=', $startDate)
                ->where('pesanan.tanggal_pesan <=', $endDate . ' 23:59:59');
        }

        if ($status) {
            $query->where('pesanan.status', $status);
        }

        // Always sort by oldest date first
        $orders = $query->orderBy('tanggal_pesan', 'ASC')->findAll();

        // Build HTML for response
        $html = '';
        foreach ($orders as $key => $order) {
            $html .= '<tr>';
            $html .= '<td>' . ($key + 1) . '</td>';
            $html .= '<td>' . $order['nama_customer'] . '</td>';
            $html .= '<td>' . date('d-m-Y', strtotime($order['tanggal_pesan'])) . '</td>';
            $html .= '<td>' . $order['jumlah_pesan'] . '</td>';
            $html .= '<td>Rp ' . number_format($order['harga'], 0, ',', '.') . '</td>';
            $html .= '<td>Rp ' . number_format($order['jumlah_pesan'] * $order['harga'], 0, ',', '.') . '</td>';
            $html .= '<td>' . ucfirst($order['status']) . '</td>';
            $html .= '</tr>';
        }

        return $this->response->setJSON(['html' => $html]);
    }

    public function printOrderReport()
    {
        $startDate = $this->request->getGet('start_date');
        $endDate = $this->request->getGet('end_date');
        $status = $this->request->getGet('status');

        $query = $this->pesananModel->select('pesanan.*, customers.nama_customer, customers.alamat, customers.no_telepon')
            ->join('customers', 'customers.id = pesanan.user_id');

        // Apply filters
        if ($startDate && $endDate) {
            $query->where('pesanan.tanggal_pesan >=', $startDate)
                ->where('pesanan.tanggal_pesan <=', $endDate . ' 23:59:59');
        }

        if ($status) {
            $query->where('pesanan.status', $status);
        }

        // Always sort by oldest date first
        $data['orders'] = $query->orderBy('tanggal_pesan', 'ASC')->findAll();
        $data['start_date'] = $startDate;
        $data['end_date'] = $endDate;

        // Calculate totals
        $data['total_orders'] = count($data['orders']);
        $data['total_amount'] = array_reduce($data['orders'], function ($carry, $order) {
            return $carry + ($order['jumlah_pesan'] * $order['harga']);
        }, 0);

        // Load view for PDF
        $html = view('reports/order_report_pdf', $data);

        // Setup PDF
        $options = new \Dompdf\Options();
        $options->setDefaultFont('Courier');
        $dompdf = new \Dompdf\Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        return $dompdf->stream('laporan_pesanan.pdf', ['Attachment' => false]);
    }

    public function financialReport()
    {
        $data = $this->getFinancialData();
        return view('reports/view_financial_report', $data);
    }

    private function getFinancialData($startDate = null, $endDate = null)
    {
        $query = $this->pesananModel->select('
        pesanan.*, 
        customers.nama_customer,
        customers.alamat,
        customers.no_telepon
    ')
            ->join('customers', 'customers.id = pesanan.user_id');

        if ($startDate && $endDate) {
            $query->where('pesanan.tanggal_pesan >=', $startDate)
                ->where('pesanan.tanggal_pesan <=', $endDate . ' 23:59:59');
        }

        $orders = $query->findAll();

        // Hitung ringkasan
        $summary = [
            'total_pendapatan' => 0,
            'total_pesanan' => count($orders),
            'rata_rata_pesanan' => 0,
            'pendapatan_per_status' => [
                'antri' => 0,
                'proses' => 0,
                'selesai' => 0
            ],
            'top_customers' => []
        ];

        // Data untuk grafik
        $monthlyRevenue = [];

        // Data per customer untuk menghitung top customers
        $customerRevenue = [];

        foreach ($orders as $order) {
            $total = $order['jumlah_pesan'] * $order['harga'];
            $summary['total_pendapatan'] += $total;
            $summary['pendapatan_per_status'][$order['status']] += $total;

            // Hitung pendapatan per customer
            if (!isset($customerRevenue[$order['nama_customer']])) {
                $customerRevenue[$order['nama_customer']] = 0;
            }
            $customerRevenue[$order['nama_customer']] += $total;

            // Kelompokkan pendapatan per bulan untuk grafik
            $monthYear = date('Y-m', strtotime($order['tanggal_pesan']));
            if (!isset($monthlyRevenue[$monthYear])) {
                $monthlyRevenue[$monthYear] = 0;
            }
            $monthlyRevenue[$monthYear] += $total;
        }

        // Hitung rata-rata pesanan
        $summary['rata_rata_pesanan'] = $summary['total_pesanan'] > 0 ?
            $summary['total_pendapatan'] / $summary['total_pesanan'] : 0;

        // Ambil 5 customer dengan pendapatan tertinggi
        arsort($customerRevenue);
        $summary['top_customers'] = array_slice($customerRevenue, 0, 5, true);

        // Urutkan data grafik berdasarkan bulan
        ksort($monthlyRevenue);

        return [
            'orders' => $orders,
            'summary' => $summary,
            'monthlyRevenue' => $monthlyRevenue
        ];
    }

    public function getFilteredFinancialReport()
    {
        $startDate = $this->request->getPost('start_date');
        $endDate = $this->request->getPost('end_date');

        $data = $this->getFinancialData($startDate, $endDate);
        return $this->response->setJSON($data);
    }

    public function printFinancialReport()
    {
        $startDate = $this->request->getGet('start_date');
        $endDate = $this->request->getGet('end_date');

        $data = $this->getFinancialData($startDate, $endDate);
        $data['start_date'] = $startDate;
        $data['end_date'] = $endDate;

        // Load view
        $html = view('reports/financial_report_pdf', $data);

        // Setup PDF
        $options = new \Dompdf\Options();
        $options->setDefaultFont('Courier');
        $dompdf = new \Dompdf\Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        return $dompdf->stream('laporan_keuangan.pdf', ['Attachment' => false]);
    }
}
