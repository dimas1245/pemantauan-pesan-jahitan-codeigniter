<?php

namespace App\Controllers\Register;

use App\Models\CustomerModel;

class CustomerController extends \CodeIgniter\Controller
{
    // Menampilkan form data diri customer
    public function form()
    {
        $session = session();
        $userId = $session->get('user_id'); // Ambil user_id dari session

        // Cek apakah user_id masih ada di session
        if (!$userId) {
            // Jika user_id tidak ada, redirect ke dashboard customer
            return redirect()->to('/customer/dashboard');
        }

        // Tampilkan form data diri customer
        return view('customer/form');
    }

    // Menyimpan form data diri customer
    public function saveForm()
    {
        $session = session();
        $model = new CustomerModel();

        $userId = $session->get('user_id'); // Ambil user_id dari session
        $nama = $this->request->getPost('nama_customer');
        $alamat = $this->request->getPost('alamat');
        $noTelepon = $this->request->getPost('no_telepon');

        // Validasi input
        if (empty($nama) || empty($alamat) || empty($noTelepon)) {
            $session->setFlashdata('error', 'Semua field harus diisi');
            return redirect()->back()->withInput();
        }

        // Simpan data customer ke database
        $data = [
            'user_id' => $userId,
            'nama_customer' => $nama,
            'alamat' => $alamat,
            'no_telepon' => $noTelepon
        ];

        if ($model->insert($data)) {
            // Redirect ke dashboard customer dengan pesan sukses
            return redirect()->to('/customer/dashboard')->with('success', 'Data berhasil disimpan');
        } else {
            $session->setFlashdata('error', 'Gagal menyimpan data diri');
            return redirect()->back()->withInput();
        }
    }

    public function profile()
    {
        $session = session();
        $userId = $session->get('user_id');

        log_message('debug', 'User ID: ' . $userId); // Debugging session user_id

        if (!$userId) {
            return redirect()->to('/customer/dashboard')->with('error', 'Data profile tidak ditemukan.');
        }

        // Ambil data customer berdasarkan user_id
        $model = new CustomerModel();
        $customer = $model->where('user_id', $userId)->first();

        if (!$customer) {
            return redirect()->to('/customer/dashboard')->with('error', 'Data customer tidak ditemukan.');
        }

        return view('customer/profile', ['customer' => $customer]);
    }


    // Update data profil customer
    public function updateProfile()
    {
        $session = session();
        $userId = $session->get('user_id'); // Ambil user_id dari session

        $model = new CustomerModel();

        // Ambil data dari form
        $nama = $this->request->getPost('nama_customer');
        $alamat = $this->request->getPost('alamat');
        $noTelepon = $this->request->getPost('no_telepon');

        // Validasi input
        if (empty($nama) || empty($alamat) || empty($noTelepon)) {
            return redirect()->back()->with('error', 'Semua field harus diisi.');
        }

        // Update data customer di database
        $data = [
            'nama_customer' => $nama,
            'alamat' => $alamat,
            'no_telepon' => $noTelepon,
        ];

        if ($model->where('user_id', $userId)->set($data)->update()) {
            return redirect()->to('/customer/profile')->with('success', 'Profile berhasil diperbarui.');
        } else {
            return redirect()->back()->with('error', 'Gagal memperbarui profile.');
        }
    }
}
