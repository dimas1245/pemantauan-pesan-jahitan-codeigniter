<?php

namespace App\Controllers\Register;

use App\Models\UserModel;

class RegisterController extends \CodeIgniter\Controller
{
    public function index()
    {
        // Tampilkan halaman form registrasi
        return view('auth/register');
    }

    public function store()
    {
        $session = session();
        $model = new UserModel();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $confirmPassword = $this->request->getPost('confirm_password');

        // Validasi input
        if (empty($username) || empty($password) || empty($confirmPassword)) {
            $session->setFlashdata('error', 'Semua field harus diisi');
            return redirect()->back()->withInput();
        }

        if ($password !== $confirmPassword) {
            $session->setFlashdata('error', 'Password tidak cocok');
            return redirect()->back()->withInput();
        }

        // Simpan user ke database (tanpa hash password)
        $data = [
            'username' => $username,
            'password' => $password, // Simpan password tanpa hash
            'role_id' => 2 // Default role untuk customer
        ];

        if ($model->insert($data)) {
            // Ambil ID user yang baru saja dibuat
            $userId = $model->insertID();

            // Simpan user_id di session untuk tahap berikutnya
            $session->set('user_id', $userId);

            // Redirect ke form data diri customer
            return redirect()->to('/customer/form');
        } else {
            $session->setFlashdata('error', 'Registrasi gagal. Coba lagi.');
            return redirect()->back()->withInput();
        }
    }
}
