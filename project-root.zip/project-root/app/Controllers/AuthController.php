<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class AuthController extends Controller
{
    public function login()
    {
        return view('login'); // Tampilkan halaman login
    }

    public function loginAttempt()
    {
        $session = session();
        $model = new UserModel();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // Cari pengguna berdasarkan username
        $user = $model->getUserByUsername($username);

        if ($user) {
            // Cek password (tanpa hash, hanya perbandingan langsung)
            if ($password === $user['password']) {
                // Set session data jika login berhasil
                $session->set([
                    'isLoggedIn' => true,
                    'username' => $user['username'],
                    'role_id' => $user['role_id'],
                    'user_id' => $user['id'] // Tambahkan user_id ke session
                ]);

                // Redirect berdasarkan role
                if ($user['role_id'] == 1) { // admin
                    return redirect()->to('/admin/dashboard');
                } else { // customer
                    return redirect()->to('/customer/dashboard');
                }
            } else {
                $session->setFlashdata('error', 'Password salah');
                return redirect()->back();
            }
        } else {
            $session->setFlashdata('error', 'Username tidak ditemukan');
            return redirect()->back();
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
