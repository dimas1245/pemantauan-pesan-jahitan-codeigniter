<?php

namespace App\Controllers\Admin;

use CodeIgniter\Controller;
use App\Models\PesananModel;
use App\Models\CustomerModel;
use App\Models\UserModel; // Ganti UserModel dengan CustomerModel

class DashboardController extends Controller
{
    protected $pesananModel;
    protected $customerModel;
    protected $userModel;

    public function __construct()
    {
        $this->pesananModel = new PesananModel();
        $this->customerModel = new CustomerModel();
        $this->userModel = new UserModel();
    }

    public function index()
    {
        $data['pesanan'] = $this->pesananModel->getPesananWithCustomer();
        return view('admin/dashboard', $data);
    }

    public function tambahPesanan()
    {
        // Jika request AJAX untuk get alamat
        if ($this->request->isAJAX()) {
            $nama_customer = $this->request->getPost('nama_customer');
            $customer = $this->customerModel->where('nama_customer', $nama_customer)->first();

            if ($customer) {
                return $this->response->setJSON([
                    'success' => true,
                    'user_id' => $customer['id'],
                    'alamat' => $customer['alamat'],
                    'no_telepon' => $customer['no_telepon']
                ]);
            }
            return $this->response->setJSON(['success' => false]);
        }

        // Get pesanan_id if it exists (for update)
        $pesanan_id = $this->request->getPost('pesanan_id');

        // Prepare data for insert/update
        $data = [
            'user_id' => $this->request->getPost('user_id'),
            'tanggal_pesan' => $this->request->getPost('tanggal_pesan'),
            'jumlah_pesan' => $this->request->getPost('jumlah_pesan'),
            'harga' => $this->request->getPost('harga'),
            'status' => $this->request->getPost('status')
        ];

        try {
            if ($pesanan_id) {
                // If pesanan_id exists, update existing record
                $this->pesananModel->update($pesanan_id, $data);
                $message = 'Pesanan berhasil diupdate';
            } else {
                // If no pesanan_id, insert new record
                $this->pesananModel->insert($data);
                $message = 'Pesanan berhasil ditambahkan';
            }

            return redirect()->to(base_url('admin/dashboard'))
                ->with('success', $message);
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Gagal ' . ($pesanan_id ? 'mengupdate' : 'menambahkan') . ' pesanan: ' . $e->getMessage())
                ->withInput();
        }
    }

    public function updateStatus($id)
    {
        $data['status'] = $this->request->getPost('status');
        $this->pesananModel->update($id, $data);
        return redirect()->to('/admin/dashboard')->with('success', 'Status berhasil diupdate');
    }

    public function getCustomerInfo()
    {
        if ($this->request->isAJAX()) {
            $nama_customer = $this->request->getPost('nama_customer');

            // Debug: print received name
            log_message('debug', 'Received nama_customer: ' . $nama_customer);

            $customer = $this->customerModel->where('nama_customer', $nama_customer)->first();

            // Debug: print query result
            log_message('debug', 'Query result: ' . json_encode($customer));

            if ($customer) {
                return $this->response->setJSON([
                    'success' => true,
                    'user_id' => $customer['id'],
                    'alamat' => $customer['alamat'],
                    'no_telepon' => $customer['no_telepon']
                ]);
            }
            return $this->response->setJSON([
                'success' => false,
                'alamat' => '',
                'no_telepon' => '',
                'user_id' => ''
            ]);
        }
    }

    public function getPesananById()
    {
        if ($this->request->isAJAX()) {
            $id = $this->request->getPost('id');

            // Join with customers table to get customer details
            $pesanan = $this->pesananModel->select('pesanan.*, customers.nama_customer, customers.alamat, customers.no_telepon')
                ->join('customers', 'customers.id = pesanan.user_id')
                ->find($id);

            if ($pesanan) {
                return $this->response->setJSON([
                    'success' => true,
                    'user_id' => $pesanan['user_id'],
                    'nama_customer' => $pesanan['nama_customer'],
                    'alamat' => $pesanan['alamat'],
                    'no_telepon' => $pesanan['no_telepon'],
                    'tanggal_pesan' => $pesanan['tanggal_pesan'],
                    'jumlah_pesan' => $pesanan['jumlah_pesan'],
                    'harga' => $pesanan['harga'],
                    'status' => $pesanan['status']
                ]);
            } else {
                return $this->response->setJSON(['success' => false]);
            }
        }
    }

    public function deletePesanan($id)
    {
        if ($this->request->isAJAX()) {
            try {
                // Coba hapus data
                if ($this->pesananModel->delete($id)) {
                    return $this->response->setJSON([
                        'success' => true,
                        'message' => 'Pesanan berhasil dihapus'
                    ]);
                } else {
                    return $this->response->setJSON([
                        'success' => false,
                        'message' => 'Gagal menghapus pesanan'
                    ]);
                }
            } catch (\Exception $e) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Error: ' . $e->getMessage()
                ]);
            }
        }
    }

    public function resetPassword($userId)
    {
        // Check if user is admin
        if (session()->get('role_id') != 1) {
            return redirect()->back()->with('error', 'Unauthorized access');
        }

        try {
            // Reset password tanpa hash dan dapatkan password barunya
            $newPassword = $this->userModel->resetPassword($userId);

            // Tampilkan pesan sukses dengan password baru
            session()->setFlashdata('success', 'Password telah direset. Password baru: ' . $newPassword);
        } catch (\Exception $e) {
            session()->setFlashdata('error', 'Gagal mereset password: ' . $e->getMessage());
        }

        // Redirect kembali ke halaman laporan
        return redirect()->to('report/registration/view');
    }
}
