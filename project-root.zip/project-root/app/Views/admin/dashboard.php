<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom styles to make the table more compact */
        .table th, .table td {
            padding: 0.3rem; /* Reduce padding */
        }
        .table {
            font-size: 0.9rem; /* Reduce font size */
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Admin Dashboard</h1>
            <a href="<?= base_url('/logout') ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                Logout
            </a>
        </div>
        <!-- Report Buttons Section -->
        <div class="card mt-4">
            <div class="card-header">
                <h5>Cetak Laporan</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-2">
                        <a href="<?= base_url('report/customer') ?>" class="btn btn-primary w-100" target="_blank">
                            Laporan Customer
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="<?= base_url('report/registration/view') ?>" class="btn btn-success w-100">
                            Laporan Registrasi
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="<?= base_url('report/order') ?>" class="btn btn-info w-100" target="_blank">
                            Laporan Pesanan
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="<?= base_url('report/financial') ?>" class="btn btn-warning w-100" target="_blank">
                            Laporan Keuangan
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Form Tambah Pesanan -->
        <div class="card mt-4">
            <div class="card-header">
                <h5>Tambah Pesanan Jahitan</h5>
            </div>
            <div class="card-body">
                <form id="formPesanan" action="<?= base_url('admin/dashboard/tambahPesanan') ?>" method="POST">
                    <input type="hidden" name="user_id" id="user_id" required>
                    <div class="mb-3">
                        <label class="form-label">Nama Customer</label>
                        <input type="text" class="form-control" name="nama_customer" id="nama_customer" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Alamat</label>
                        <input type="text" class="form-control" name="alamat" id="alamat" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">No Telepon</label>
                        <input type="text" class="form-control" name="no_telepon" id="no_telepon" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tanggal Pesan</label>
                        <input type="date" class="form-control" name="tanggal_pesan" id="tanggal_pesan" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jumlah Pesan</label>
                        <input type="number" class ="form-control" name="jumlah_pesan" id="jumlah_pesan" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Harga</label>
                        <input type="number" class="form-control" name="harga" id="harga" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="status" id="status" required>
                            <option value="antri">Antri</option>
                            <option value="proses">Proses</option>
                            <option value="selesai">Selesai</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>

        <!-- Input Pencarian -->
        <div class="card mt-4">
            <div class="card-header">
                <h5>Cari Pesanan</h5>
            </div>
            <div class="card-body">
                <input type="text" id="searchInput" class="form-control" placeholder="Cari berdasarkan nama customer...">
            </div>
        </div>

        <!-- Tabel Pesanan -->
        <div class="card mt-4">
            <div class="card-header">
                <h5>Daftar Pesanan</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Customer</th>
                            <th>Alamat</th>
                            <th>No Telepon</th>
                            <th>Tanggal Pesan</th>
                            <th>Jumlah</th>
                            <th>Harga</th>
                            <th>Total Harga</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="pesananTableBody">
                        <?php foreach ($pesanan as $key => $p): ?>
                            <tr>
                                <td><?= $key + 1 ?></td>
                                <td><?= $p['nama_customer'] ?></td>
                                <td><?= $p['alamat'] ?></td>
                                <td><?= $p['no_telepon'] ?></td>
                                <td><?= $p['tanggal_pesan'] ?></td>
                                <td><?= $p['jumlah_pesan'] ?></td>
                                <td><?= $p['harga'] ?></td>
                                <td><?= number_format($p['jumlah_pesan'] * $p['harga'], 0, ',', '.') ?></td>
                                <td><?= $p['status'] ?></td>
                                <td>
                                    <button type="button" class="btn btn-warning btn-sm edit-btn" data-id="<?= $p['id'] ?>">Edit</button>
                                    <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="<?= $p['id'] ?>">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#searchInput').on('input', function() {
                let searchValue = $(this).val().toLowerCase();
                $('#pesananTableBody tr').filter(function() {
                    $(this).toggle($(this).find('td:nth-child(2)').text().toLowerCase().indexOf(searchValue) > -1);
                });
            });

            $('#nama_customer').on('input', function() {
                let nama = $(this).val();
                console.log('Input detected:', nama); // Debug log

                $.ajax({
                    url: '<?= base_url('admin/dashboard/getCustomerInfo') ?>',
                    type: 'POST',
                    dataType: 'json', // Specify expected data type
                    data: {
                        nama_customer: nama
                    },
                    success: function(response) {
                        console.log('Response received:', response); // Debug log
                        if (response.success) {
                            $('#alamat').val(response.alamat);
                            $('#user_id').val(response.user_id);
                            $('#no_telepon').val(response.no_telepon); // Set no telepon
                        } else {
                            $('#alamat').val('');
                            $('#no_telepon').val('');
                            $('#user_id').val('');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Ajax Error:', error); // Debug log
                        $('#alamat').val ('');
                        $('#no_telepon').val('');
                        $('#user_id').val('');
                    }
                });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Handle edit button click
            $('.edit-btn').click(function() {
                var id = $(this).data('id');

                // AJAX request to get pesanan data
                $.ajax({
                    url: '<?= base_url('admin/dashboard/getPesananById') ?>',
                    type: 'POST',
                    data: {
                        id: id
                    },
                    success: function(response) {
                        if (response.success) {
                            // Fill the form with existing data
                            $('#user_id').val(response.user_id);
                            $('#nama_customer').val(response.nama_customer);
                            $('#alamat').val(response.alamat);
                            $('#no_telepon').val(response.no_telepon);
                            $('#tanggal_pesan').val(response.tanggal_pesan);
                            $('#jumlah_pesan').val(response.jumlah_pesan);
                            $('#harga').val(response.harga);
                            $('#status').val(response.status);

                            // Add hidden input for ID
                            if ($('#pesanan_id').length === 0) {
                                $('<input>').attr({
                                    type: 'hidden',
                                    id: 'pesanan_id',
                                    name: 'pesanan_id',
                                    value: id
                                }).appendTo('#formPesanan');
                            } else {
                                $('#pesanan_id').val(id);
                            }

                            // Scroll to form
                            $('html, body').animate({
                                scrollTop: $("#formPesanan").offset().top
                            }, 500);
                        }
                    }
                });
            });

            // Handle delete button click
            $('.delete-btn').click(function() {
                if (confirm('Apakah Anda yakin ingin menghapus pesanan ini?')) {
                    var id = $(this).data('id');

                    $.ajax({
                        url: '<?= base_url('admin/dashboard/deletePesanan/') ?>' + id,
                        type: 'POST',
                        success: function(response) {
                            if (response.success) {
                                // Jika berhasil, reload halaman
                                alert(response.message);
                                location.reload();
                            } else {
                                // Jika gagal, tampilkan pesan error
                                alert('Gagal menghapus pesanan: ' + response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('Terjadi kesalahan: ' + error);
                        }
                    });
                }
            });
        });
    </script>
</body>

</html>