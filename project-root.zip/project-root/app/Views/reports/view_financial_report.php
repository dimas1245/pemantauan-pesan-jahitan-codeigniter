<!-- app/Views/reports/view_financial_report.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Keuangan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <!-- Tambahkan Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">Laporan Keuangan</h3>
                <a href="<?= base_url('admin/dashboard') ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
            <div class="card-body">
                <!-- Filter Form -->
                <form id="filterForm" class="row mb-4">
                    <div class="col-md-4">
                        <label class="form-label">Tanggal Awal</label>
                        <input type="date" class="form-control" id="start_date" name="start_date">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Tanggal Akhir</label>
                        <input type="date" class="form-control" id="end_date" name="end_date">
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                        <button type="button" class="btn btn-success" onclick="printReport()">
                            <i class="fas fa-print"></i> Cetak PDF
                        </button>
                    </div>
                </form>

                <!-- Summary Cards -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card bg-primary text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Pendapatan</h5>
                                <h3 class="card-text" id="total_pendapatan">
                                    Rp <?= number_format($summary['total_pendapatan'], 0, ',', '.') ?>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Pesanan</h5>
                                <h3 class="card-text" id="total_pesanan">
                                    <?= $summary['total_pesanan'] ?>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-info text-white">
                            <div class="card-body">
                                <h5 class="card-title">Rata-rata Pesanan</h5>
                                <h3 class="card-text" id="rata_rata_pesanan">
                                    Rp <?= number_format($summary['rata_rata_pesanan'], 0, ',', '.') ?>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts Row -->
                <div class="row mb-4">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Tren Pendapatan Bulanan</h5>
                                <canvas id="revenueChart"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Top 5 Customer</h5>
                                <div id="topCustomers">
                                    <?php foreach ($summary['top_customers'] as $customer => $revenue): ?>
                                        <div class="d-flex justify-content-between mb-2">
                                            <span><?= $customer ?></span>
                                            <span>Rp <?= number_format($revenue, 0, ',', '.') ?></span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Transaction Table -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Detail Transaksi</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead class="table-dark">
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Customer</th>
                                        <th>Jumlah</th>
                                        <th>Harga</th>
                                        <th>Total</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $grandTotal = 0;
                                    foreach ($orders as $key => $order):
                                        $total = $order['jumlah_pesan'] * $order['harga'];
                                        $grandTotal += $total;
                                    ?>
                                        <tr>
                                            <td><?= $key + 1 ?></td>
                                            <td><?= date('d-m-Y', strtotime($order['tanggal_pesan'])) ?></td>
                                            <td><?= $order['nama_customer'] ?></td>
                                            <td><?= $order['jumlah_pesan'] ?></td>
                                            <td>Rp <?= number_format($order['harga'], 0, ',', '.') ?></td>
                                            <td>Rp <?= number_format($total, 0, ',', '.') ?></td>
                                            <td>
                                                <span class="badge bg-<?= $order['status'] == 'selesai' ? 'success' : ($order['status'] == 'proses' ? 'warning' : 'info') ?>">
                                                    <?= ucfirst($order['status']) ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr class="table-dark">
                                        <td colspan="5" class="text-end"><strong>Total Keseluruhan:</strong></td>
                                        <td colspan="2"><strong>Rp <?= number_format($grandTotal, 0, ',', '.') ?></strong></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Initialize date pickers
        flatpickr("#start_date", {
            dateFormat: "Y-m-d"
        });
        flatpickr("#end_date", {
            dateFormat: "Y-m-d"
        });

        // Initialize revenue chart
        const monthlyData = <?= json_encode($monthlyRevenue) ?>;
        const ctx = document.getElementById('revenueChart').getContext('2d');
        const revenueChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Object.keys(monthlyData),
                datasets: [{
                    label: 'Pendapatan Bulanan',
                    data: Object.values(monthlyData),
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1,
                    fill: true,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Grafik Pendapatan Bulanan'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + numberFormat(value);
                            }
                        }
                    }
                }
            }
        });

        // Handle form submission
        $('#filterForm').on('submit', function(e) {
            e.preventDefault();
            loadReport();
        });

        function loadReport() {
            $.ajax({
                url: '<?= base_url('report/getFilteredFinancialReport') ?>',
                type: 'POST',
                data: {
                    start_date: $('#start_date').val(),
                    end_date: $('#end_date').val()
                },
                success: function(response) {
                    updateDashboard(response);
                }
            });
        }

        function updateDashboard(data) {
            // Update summary cards
            $('#total_pendapatan').text('Rp ' + numberFormat(data.summary.total_pendapatan));
            $('#total_pesanan').text(data.summary.total_pesanan);
            $('#rata_rata_pesanan').text('Rp ' + numberFormat(data.summary.rata_rata_pesanan));

            // Update top customers
            let topCustomersHtml = '';
            Object.entries(data.summary.top_customers).forEach(([customer, revenue]) => {
                topCustomersHtml += `
                    <div class="d-flex justify-content-between mb-2">
                        <span>${customer}</span>
                        <span>Rp ${numberFormat(revenue)}</span>
                    </div>`;
            });
            $('#topCustomers').html(topCustomersHtml);

            // Update chart
            revenueChart.data.labels = Object.keys(data.monthlyRevenue);
            revenueChart.data.datasets[0].data = Object.values(data.monthlyRevenue);
            revenueChart.update();

            // Update table
            let tableHtml = '';
            let grandTotal = 0;
            data.orders.forEach((order, index) => {
                const total = order.jumlah_pesan * order.harga;
                grandTotal += total;
                const statusClass = order.status == 'selesai' ? 'success' : (order.status == 'proses' ? 'warning' : 'info');

                tableHtml += `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${formatDate(order.tanggal_pesan)}</td>
                        <td>${order.nama_customer}</td>
                        <td>${order.jumlah_pesan}</td>
                        <td>Rp ${numberFormat(order.harga)}</td>
                        <td>Rp ${numberFormat(total)}</td>
                        <td>
                            <span class="badge bg-${statusClass}">
                                ${order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                            </span>
                        </td>
                    </tr>`;
            });

            // Add total row
            tableHtml += `
                <tr class="table-dark">
                    <td colspan="5" class="text-end"><strong>Total Keseluruhan:</strong></td>
                    <td colspan="2"><strong>Rp ${numberFormat(grandTotal)}</strong></td>
                </tr>`;

            $('tbody').html(tableHtml);
        }

        function printReport() {
            const start_date = $('#start_date').val();
            const end_date = $('#end_date').val();

            window.open(
                `<?= base_url('report/printFinancialReport') ?>?start_date=${start_date}&end_date=${end_date}`,
                '_blank'
            );
        }

        function numberFormat(number) {
            return new Intl.NumberFormat('id-ID').format(number);
        }

        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('id-ID', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric'
            }).split('/').join('-');
        }
    </script>
</body>

</html>