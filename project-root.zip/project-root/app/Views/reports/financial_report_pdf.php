<!-- app/Views/reports/financial_report_pdf.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Keuangan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        h1,
        h2 {
            text-align: center;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .filter-info {
            margin-bottom: 20px;
        }

        .summary-section {
            margin-bottom: 30px;
        }

        .summary-item {
            margin-bottom: 10px;
        }

        .total-row {
            font-weight: bold;
            background-color: #f8f9fa;
        }

        .top-customers {
            margin: 20px 0;
            page-break-inside: avoid;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Laporan Keuangan</h1>
        <p>Tanggal: <?= date('d-m-Y') ?></p>
        <?php if ($start_date && $end_date): ?>
            <p>Periode: <?= date('d-m-Y', strtotime($start_date)) ?> s/d <?= date('d-m-Y', strtotime($end_date)) ?></p>
        <?php endif; ?>
    </div>

    <div class="summary-section">
        <h2>Ringkasan</h2>
        <div class="summary-item">
            <strong>Total Pendapatan:</strong> Rp <?= number_format($summary['total_pendapatan'], 0, ',', '.') ?>
        </div>
        <div class="summary-item">
            <strong>Total Pesanan:</strong> <?= $summary['total_pesanan'] ?>
        </div>
        <div class="summary-item">
            <strong>Rata-rata Nilai Pesanan:</strong> Rp <?= number_format($summary['rata_rata_pesanan'], 0, ',', '.') ?>
        </div>
    </div>

    <div class="top-customers">
        <h2>Top 5 Customer</h2>
        <table>
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Total Pendapatan</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($summary['top_customers'] as $customer => $revenue): ?>
                    <tr>
                        <td><?= $customer ?></td>
                        <td>Rp <?= number_format($revenue, 0, ',', '.') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <h2>Detail Transaksi</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Customer</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Total</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $totalAmount = 0;
            foreach ($orders as $key => $order):
                $total = $order['jumlah_pesan'] * $order['harga'];
                $totalAmount += $total;
            ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= date('d-m-Y', strtotime($order['tanggal_pesan'])) ?></td>
                    <td><?= $order['nama_customer'] ?></td>
                    <td><?= $order['jumlah_pesan'] ?></td>
                    <td>Rp <?= number_format($order['harga'], 0, ',', '.') ?></td>
                    <td>Rp <?= number_format($total, 0, ',', '.') ?></td>
                    <td><?= ucfirst($order['status']) ?></td>
                </tr>
            <?php endforeach; ?>
            <tr class="total-row">
                <td colspan="5">Total Keseluruhan</td>
                <td>Rp <?= number_format($totalAmount, 0, ',', '.') ?></td>
                <td></td>
            </tr>
        </tbody>
    </table>
</body>

</html>