<!-- app/Views/reports/customer_report_pdf.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Data Customer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        h1 {
            text-align: center;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .filter-info {
            margin-bottom: 20px;
        }

        .total-row {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Laporan Data Customer</h1>
        <p>Tanggal: <?= date('d-m-Y') ?></p>
    </div>

    <?php if ($start_date && $end_date): ?>
        <div class="filter-info">
            <p>Periode: <?= date('d-m-Y', strtotime($start_date)) ?> s/d <?= date('d-m-Y', strtotime($end_date)) ?></p>
        </div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Customer</th>
                <th>Alamat</th>
                <th>No Telepon</th>
                <th>Total Pesanan</th>
                <th>Total Nilai Pesanan</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $totalAllOrders = 0;
            $totalAllAmount = 0;
            foreach ($orders as $key => $order):
                $totalAllOrders += $order['total_orders'];
                $totalAllAmount += $order['total_amount'];
            ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $order['nama_customer'] ?></td>
                    <td><?= $order['alamat'] ?></td>
                    <td><?= $order['no_telepon'] ?></td>
                    <td><?= $order['total_orders'] ?></td>
                    <td>Rp <?= number_format($order['total_amount'], 0, ',', '.') ?></td>
                </tr>
            <?php endforeach; ?>
            <tr class="total-row">
                <td colspan="4">Total</td>
                <td><?= $totalAllOrders ?></td>
                <td>Rp <?= number_format($totalAllAmount, 0, ',', '.') ?></td>
            </tr>
        </tbody>
    </table>
</body>

</html>