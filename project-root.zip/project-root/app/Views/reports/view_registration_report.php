<!-- app/Views/reports/view_registration_report.php -->
<!DOCTYPE html>
<html>

<head>
    <title>View Laporan Data User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>

<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Laporan Data User</h3>
            </div>
            <div class="card-body">
                <!-- Filter Form -->
                <form id="filterForm" class="row mb-4">
                    <div class="col-md-3">
                        <label class="form-label">Role</label>
                        <select class="form-select" name="role" id="role">
                            <option value="">Semua Role</option>
                            <option value="1">Admin</option>
                            <option value="2">Customer</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">Filter</button>
                        <button type="button" class="btn btn-success" onclick="printReport()">
                            <i class="fas fa-print"></i> Cetak PDF
                        </button>
                    </div>
                </form>

                <!-- Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Role</th>
                                <th>Status Customer</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $key => $user): ?>
                                <tr>
                                    <td><?= $key + 1 ?></td>
                                    <td><?= $user['username'] ?></td>
                                    <td class="password-cell"><?= $user['password'] ?></td>
                                    <td><?= $user['role_id'] == 1 ? 'Admin' : 'Customer' ?></td>
                                    <td><?= !empty($user['nama_customer']) ? 'Terdaftar' : 'Belum Terdaftar' ?></td>
                                    <td>
                                        <button onclick="resetPassword(<?= $user['id'] ?>)" class="btn btn-warning btn-sm">
                                            Reset Password
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        // Initialize date pickers
        flatpickr("#start_date", {
            dateFormat: "Y-m-d"
        });
        flatpickr("#end_date", {
            dateFormat: "Y-m-d"
        });

        // Handle form submission
        $('#filterForm').on('submit', function(e) {
            e.preventDefault();
            loadReport();
        });

        function loadReport() {
            $.ajax({
                url: '<?= base_url('report/getFilteredUsers') ?>',
                type: 'POST',
                data: {
                    role: $('#role').val()
                },
                success: function(response) {
                    $('tbody').html(response);
                }
            });
        }

        function printReport() {
            const role = $('#role').val();
            window.open(
                `<?= base_url('report/printRegistration') ?>?role=${role}`,
                '_blank'
            );
        }

        function resetPassword(userId) {
            if (confirm('Apakah Anda yakin ingin mereset password user ini?')) {
                window.location.href = '<?= base_url('admin/dashboard/resetPassword/') ?>' + userId;
            }
        }
    </script>
</body>

</html>