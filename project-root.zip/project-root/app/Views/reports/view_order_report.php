<!-- app/Views/reports/view_order_report.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Pesanan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>

<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Laporan Pesanan</h3>
            </div>
            <div class="card-body">
                <!-- Filter Form -->
                <form id="filterForm" class="row mb-4">
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Awal</label>
                        <input type="date" class="form-control" id="start_date" name="start_date">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Akhir</label>
                        <input type="date" class="form-control" id="end_date" name="end_date">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="status" id="status">
                            <option value="">Semua Status</option>
                            <option value="antri">Antri</option>
                            <option value="proses">Proses</option>
                            <option value="selesai">Selesai</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">Filter</button>
                        <button type="button" class="btn btn-success" onclick="printReport()">
                            <i class="fas fa-print"></i> Cetak PDF
                        </button>
                    </div>
                </form>

                <!-- Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Customer</th>
                                <th>Tanggal Pesan</th>
                                <th>Jumlah</th>
                                <th>Harga</th>
                                <th>Total</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $key => $order): ?>
                                <tr>
                                    <td><?= $key + 1 ?></td>
                                    <td><?= $order['nama_customer'] ?></td>
                                    <td><?= date('d-m-Y', strtotime($order['tanggal_pesan'])) ?></td>
                                    <td><?= $order['jumlah_pesan'] ?></td>
                                    <td>Rp <?= number_format($order['harga'], 0, ',', '.') ?></td>
                                    <td>Rp <?= number_format($order['jumlah_pesan'] * $order['harga'], 0, ',', '.') ?></td>
                                    <td><?= ucfirst($order['status']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        // Initialize date pickers
        flatpickr("#start_date", {
            dateFormat: "Y-m-d"
        });
        flatpickr("#end_date", {
            dateFormat: "Y-m-d"
        });

        // Handle form submission
        $('#filterForm').on('submit', function(e) {
            e.preventDefault();
            loadReport();
        });

        function loadReport() {
            $.ajax({
                url: '<?= base_url('report/getFilteredOrderReport') ?>',
                type: 'POST',
                data: {
                    start_date: $('#start_date').val(),
                    end_date: $('#end_date').val(),
                    status: $('#status').val()
                },
                success: function(response) {
                    $('tbody').html(response.html);
                }
            });
        }

        function printReport() {
            const start_date = $('#start_date').val();
            const end_date = $('#end_date').val();
            const status = $('#status').val();

            window.open(
                `<?= base_url('report/printOrderReport') ?>?start_date=${start_date}&end_date=${end_date}&status=${status}`,
                '_blank'
            );
        }
    </script>
</body>

</html>