<!-- app/Views/reports/view_customer_report.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Data Customer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>

<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Laporan Data Customer</h3>
            </div>
            <div class="card-body">
                <!-- Filter Form -->
                <form id="filterForm" class="row mb-4">
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Awal</label>
                        <input type="date" class="form-control" id="start_date" name="start_date">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Akhir</label>
                        <input type="date" class="form-control" id="end_date" name="end_date">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Customer</label>
                        <select class="form-select" name="customer_id" id="customer_id">
                            <option value="">Semua Customer</option>
                            <?php foreach ($customers as $customer): ?>
                                <option value="<?= $customer['id'] ?>"><?= $customer['nama_customer'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">Filter</button>
                        <button type="button" class="btn btn-success" onclick="printReport()">
                            <i class="fas fa-print"></i> Cetak PDF
                        </button>
                    </div>
                </form>

                <!-- Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Customer</th>
                                <th>Alamat</th>
                                <th>No Telepon</th>
                                <th>Total Pesanan</th>
                                <th>Total Nilai Pesanan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $key => $order): ?>
                                <tr>
                                    <td><?= $key + 1 ?></td>
                                    <td><?= $order['nama_customer'] ?></td>
                                    <td><?= $order['alamat'] ?></td>
                                    <td><?= $order['no_telepon'] ?></td>
                                    <td><?= $order['total_orders'] ?></td>
                                    <td>Rp <?= number_format($order['total_amount'], 0, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        // Initialize date pickers
        flatpickr("#start_date", {
            dateFormat: "Y-m-d"
        });
        flatpickr("#end_date", {
            dateFormat: "Y-m-d"
        });

        // Handle form submission
        $('#filterForm').on('submit', function(e) {
            e.preventDefault();
            loadReport();
        });

        function loadReport() {
            $.ajax({
                url: '<?= base_url('report/getFilteredCustomerReport') ?>',
                type: 'POST',
                data: {
                    start_date: $('#start_date').val(),
                    end_date: $('#end_date').val(),
                    customer_id: $('#customer_id').val()
                },
                success: function(response) {
                    $('tbody').html(response.html);
                }
            });
        }

        function printReport() {
            const start_date = $('#start_date').val();
            const end_date = $('#end_date').val();
            const customer_id = $('#customer_id').val();

            window.open(
                `<?= base_url('report/printCustomerReport') ?>?start_date=${start_date}&end_date=${end_date}&customer_id=${customer_id}`,
                '_blank'
            );
        }
    </script>
</body>

</html>