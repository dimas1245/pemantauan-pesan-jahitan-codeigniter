<!-- app/Views/reports/registration_report.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Data User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        h1 {
            text-align: center;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .password-cell {
            font-family: monospace;
            background-color: #f9f9f9;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Laporan Data User</h1>
        <p>Tanggal: <?= date('d-m-Y') ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Username</th>
                <th>Password</th>
                <th>Role</th>
                <th>Status Customer</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $key => $user): ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $user['username'] ?></td>
                    <td class="password-cell"><?= $user['password'] ?></td>
                    <td><?= $user['role_id'] == 1 ? 'Admin' : 'Customer' ?></td>
                    <td><?= !empty($user['nama_customer']) ? 'Terdaftar' : 'Belum Terdaftar' ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>