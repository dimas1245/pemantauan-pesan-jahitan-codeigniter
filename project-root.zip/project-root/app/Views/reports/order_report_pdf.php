<!-- app/Views/reports/order_report_pdf.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Pesanan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        h1 {
            text-align: center;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .filter-info {
            margin-bottom: 20px;
        }

        .total-row {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Laporan Pesanan</h1>
        <p>Tanggal: <?= date('d-m-Y') ?></p>
    </div>

    <?php if ($start_date && $end_date): ?>
        <div class="filter-info">
            <p>Periode: <?= date('d-m-Y', strtotime($start_date)) ?> s/d <?= date('d-m-Y', strtotime($end_date)) ?></p>
        </div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Customer</th>
                <th>Tanggal Pesan</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Total</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $key => $order): ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $order['nama_customer'] ?></td>
                    <td><?= date('d-m-Y', strtotime($order['tanggal_pesan'])) ?></td>
                    <td><?= $order['jumlah_pesan'] ?></td>
                    <td>Rp <?= number_format($order['harga'], 0, ',', '.') ?></td>
                    <td>Rp <?= number_format($order['jumlah_pesan'] * $order['harga'], 0, ',', '.') ?></td>
                    <td><?= ucfirst($order['status']) ?></td>
                </tr>
            <?php endforeach; ?>
            <tr class="total-row">
                <td colspan="3">Total</td>
                <td><?= $total_orders ?></td>
                <td>-</td>
                <td>Rp <?= number_format($total_amount, 0, ',', '.') ?></td>
                <td>-</td>
            </tr>
        </tbody>
    </table>
</body>

</html>