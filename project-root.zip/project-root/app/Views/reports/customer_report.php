<!-- app/Views/reports/customer_report.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Data Customer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        h1 {
            text-align: center;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Laporan Data Customer</h1>
        <p>Tanggal: <?= date('d-m-Y') ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Customer</th>
                <th>Alamat</th>
                <th>No Telepon</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($customers as $key => $customer): ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $customer['nama_customer'] ?></td>
                    <td><?= $customer['alamat'] ?></td>
                    <td><?= $customer['no_telepon'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>

<!-- app/Views/reports/registration_report.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Registrasi Pelanggan</title>
    <style>
        /* Same CSS as above */
    </style>
</head>

<body>
    <div class="header">
        <h1>Laporan Registrasi Pelanggan</h1>
        <p>Tanggal: <?= date('d-m-Y') ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Alamat</th>
                <th>No Telepon</th>
                <th>Tanggal Registrasi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($registrations as $key => $reg): ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $reg['nama_customer'] ?></td>
                    <td><?= $reg['email'] ?></td>
                    <td><?= $reg['alamat'] ?></td>
                    <td><?= $reg['no_telepon'] ?></td>
                    <td><?= date('d-m-Y', strtotime($reg['created_at'])) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>

<!-- app/Views/reports/order_report.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Pesanan</title>
    <style>
        /* Same CSS as above */
    </style>
</head>

<body>
    <div class="header">
        <h1>Laporan Pesanan</h1>
        <p>Tanggal: <?= date('d-m-Y') ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Customer</th>
                <th>Tanggal Pesan</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $key => $order): ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $order['nama_customer'] ?></td>
                    <td><?= date('d-m-Y', strtotime($order['tanggal_pesan'])) ?></td>
                    <td><?= $order['jumlah_pesan'] ?></td>
                    <td>Rp <?= number_format($order['harga'], 0, ',', '.') ?></td>
                    <td><?= ucfirst($order['status']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>

<!-- app/Views/reports/financial_report.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Laporan Keuangan</title>
    <style>
        /* Same CSS as above */
        .total {
            margin-top: 20px;
            text-align: right;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Laporan Keuangan</h1>
        <p>Tanggal: <?= date('d-m-Y') ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Nama Customer</th>
                <th>Jumlah Pesanan</th>
                <th>Harga</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($transactions as $key => $trans): ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= date('d-m-Y', strtotime($trans['tanggal_pesan'])) ?></td>
                    <td><?= $trans['nama_customer'] ?></td>
                    <td><?= $trans['jumlah_pesan'] ?></td>
                    <td>Rp <?= number_format($trans['harga'], 0, ',', '.') ?></td>
                    <td>Rp <?= number_format($trans['harga'] * $trans['jumlah_pesan'], 0, ',', '.') ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="total">
        Total Pendapatan: Rp <?= number_format($total_revenue, 0, ',', '.') ?>
    </div>
</body>

</html>