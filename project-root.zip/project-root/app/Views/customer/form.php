<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Data Diri</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .form-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .form-card {
            max-width: 500px;
            width: 100%;
            padding: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            background: white;
        }

        .form-title {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }

        .alert {
            margin-bottom: 20px;
        }

        textarea.form-control {
            min-height: 100px;
        }
    </style>
</head>

<body>
    <div class="form-container">
        <div class="form-card">
            <h2 class="form-title">Form Data Diri Customer</h2>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= session()->getFlashdata('error') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= session()->getFlashdata('success') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form action="<?= base_url('customer/saveForm') ?>" method="post">
                <?= csrf_field() ?>

                <div class="mb-3">
                    <label for="nama_customer" class="form-label">Nama Customer</label>
                    <input type="text"
                        class="form-control <?= session()->getFlashdata('errors.nama_customer') ? 'is-invalid' : '' ?>"
                        name="nama_customer"
                        id="nama_customer"
                        value="<?= old('nama_customer') ?>"
                        required>
                    <?php if (session()->getFlashdata('errors.nama_customer')): ?>
                        <div class="invalid-feedback">
                            <?= session()->getFlashdata('errors.nama_customer') ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <textarea class="form-control <?= session()->getFlashdata('errors.alamat') ? 'is-invalid' : '' ?>"
                        name="alamat"
                        id="alamat"
                        required><?= old('alamat') ?></textarea>
                    <?php if (session()->getFlashdata('errors.alamat')): ?>
                        <div class="invalid-feedback">
                            <?= session()->getFlashdata('errors.alamat') ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="no_telepon" class="form-label">No Telepon</label>
                    <input type="tel"
                        class="form-control <?= session()->getFlashdata('errors.no_telepon') ? 'is-invalid' : '' ?>"
                        name="no_telepon"
                        id="no_telepon"
                        value="<?= old('no_telepon') ?>"
                        required
                        pattern="[0-9]{10,13}"
                        title="Nomor telepon harus berisi 10-13 digit angka">
                    <?php if (session()->getFlashdata('errors.no_telepon')): ?>
                        <div class="invalid-feedback">
                            <?= session()->getFlashdata('errors.no_telepon') ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Simpan Data</button>
                    <a href="<?= base_url('customer/dashboard') ?>" class="btn btn-secondary">Kembali ke Dashboard</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Phone number validation
        document.getElementById('no_telepon').addEventListener('input', function(e) {
            let value = e.target.value;

            // Remove any non-digit characters
            value = value.replace(/\D/g, '');

            // Limit to 13 digits
            if (value.length > 13) {
                value = value.slice(0, 13);
            }

            e.target.value = value;
        });
    </script>
</body>

</html>