<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Dashboard Customer</h1>
            <div>
                <a href="<?= base_url('customer/profile') ?>" class="btn btn-primary me-2">Profile</a>
                <a href="<?= base_url('logout') ?>" class="btn btn-danger">Logout</a>
            </div>
        </div>

        <!-- Info Customer -->
        <?php if (isset($customer) && $customer): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Informasi Customer</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Nama:</strong> <?= esc($customer['nama_customer']) ?></p>
                            <p><strong>No. Telepon:</strong> <?= esc($customer['no_telepon']) ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Alamat:</strong> <?= esc($customer['alamat']) ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Tabel Pesanan -->
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Riwayat Pesanan</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal Pesan</th>
                                <th>Jumlah Pesanan</th>
                                <th>Total Harga</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (isset($pesanan) && !empty($pesanan)): ?>
                                <?php foreach ($pesanan as $key => $p): ?>
                                    <tr>
                                        <td><?= $key + 1 ?></td>
                                        <td><?= date('d-m-Y', strtotime($p['tanggal_pesan'])) ?></td>
                                        <td><?= esc($p['jumlah_pesan']) ?></td>
                                        <td><?= number_format($p['jumlah_pesan'] * $p['harga'], 0, ',', '.') ?></td>
                                        <td>
                                            <span class="badge <?php
                                                                switch ($p['status']) {
                                                                    case 'antri':
                                                                        echo 'bg-warning';
                                                                        break;
                                                                    case 'proses':
                                                                        echo 'bg-info';
                                                                        break;
                                                                    case 'selesai':
                                                                        echo 'bg-success';
                                                                        break;
                                                                    default:
                                                                        echo 'bg-secondary';
                                                                }
                                                                ?>">
                                                <?= ucfirst(esc($p['status'])) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">Belum ada pesanan</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>