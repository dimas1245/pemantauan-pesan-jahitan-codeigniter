<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/login', 'AuthController::login');
$routes->post('/auth/loginAttempt', 'AuthController::loginAttempt');
$routes->get('/logout', 'AuthController::logout');

// Route untuk admin dashboard
$routes->get('/admin/dashboard', 'Admin\DashboardController::index');
// Route untuk customer dashboard
$routes->get('/customer/dashboard', 'Customer\UserController::index');

// Route untuk Registrasi Calon Customer
$routes->get('/register', 'Register\RegisterController::index');
$routes->post('/register/store', 'Register\RegisterController::store');

// Route untuk Form data diri customer
$routes->get('/customer/form', 'Register\CustomerController::form');
$routes->post('/customer/saveForm', 'Register\CustomerController::saveForm');

// Route untuk halaman Profile Customer
$routes->get('/customer/profile', 'Register\CustomerController::profile');
$routes->post('/customer/profile/update', 'Register\CustomerController::updateProfile');


$routes->post('admin/dashboard/getCustomerInfo', 'Admin\DashboardController::getCustomerInfo');


$routes->post('admin/dashboard/tambahPesanan', 'Admin\DashboardController::tambahPesanan');


$routes->post('admin/dashboard/getPesananById', 'Admin\DashboardController::getPesananById');


$routes->post('admin/dashboard/deletePesanan/(:num)', 'Admin\DashboardController::deletePesanan/$1');


// Report Routes
$routes->get('report/customer', 'ReportController::customerReport');
$routes->get('report/registration', 'ReportController::registrationReport');
$routes->get('report/order', 'ReportController::orderReport');
$routes->get('report/financial', 'ReportController::financialReport');

$routes->get('report/registration/view', 'ReportController::viewRegistrationReport');
$routes->post('report/getFilteredUsers', 'ReportController::getFilteredUsers');
$routes->get('report/printRegistration', 'ReportController::printRegistration');


// Add this to your routes file
$routes->get('admin/dashboard/resetPassword/(:num)', 'Admin\DashboardController::resetPassword/$1');


$routes->get('report/customer', 'ReportController::customerReport');
$routes->post('report/getFilteredCustomerReport', 'ReportController::getFilteredCustomerReport');
$routes->get('report/printCustomerReport', 'ReportController::printCustomerReport');

$routes->get('report/order', 'ReportController::orderReport');
$routes->post('report/getFilteredOrderReport', 'ReportController::getFilteredOrderReport');
$routes->get('report/printOrderReport', 'ReportController::printOrderReport');

$routes->get('report/financial', 'ReportController::financialReport');
$routes->post('report/getFilteredFinancialReport', 'ReportController::getFilteredFinancialReport');
$routes->get('report/printFinancialReport', 'ReportController::printFinancialReport');
