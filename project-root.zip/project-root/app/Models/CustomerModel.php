<?php

namespace App\Models;

use CodeIgniter\Model;

class CustomerModel extends Model
{
    protected $table = 'customers';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'nama_customer', 'alamat', 'no_telepon'];
    protected $useTimestamps = false;
}
