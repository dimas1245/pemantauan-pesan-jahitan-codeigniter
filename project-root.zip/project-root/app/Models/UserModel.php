<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = ['username', 'password', 'role_id'];
    protected $useTimestamps = false;

    public function getUserByUsername($username)
    {
        return $this->where('username', $username)->first();
    }

    public function resetPassword($userId)
    {
        // Generate random password
        $newPassword = $this->generateRandomPassword();

        // Update password tanpa hash
        $this->update($userId, ['password' => $newPassword]);

        return $newPassword;
    }

    private function generateRandomPassword($length = 8)
    {
        $characters = 'Tailordeez123';
        $password = '';

        for ($i = 0; $i < $length; $i++) {
            $password .= $characters[rand(0, strlen($characters) - 1)];
        }

        return $password;
    }
}
