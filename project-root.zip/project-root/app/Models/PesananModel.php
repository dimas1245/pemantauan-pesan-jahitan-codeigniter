<?php

namespace App\Models;

use CodeIgniter\Model;

class PesananModel extends Model
{
    protected $table = 'pesanan';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'tanggal_pesan', 'jumlah_pesan', 'harga', 'status'];
    protected $useTimestamps = false;
    protected $useSoftDeletes = false; // Jika Anda ingin benar-benar menghapus data

    // Get orders with customer details
    public function getPesananWithCustomer()
    {
        return $this->select('pesanan.*, customers.nama_customer, customers.alamat, customers.no_telepon')
            ->join('customers', 'customers.id = pesanan.user_id')
            ->findAll();
    }

    // Get orders for a specific customer
    public function getPesananByCustomersId($user_id)
    {
        return $this->where('user_id', $user_id)->findAll();
    }
}
